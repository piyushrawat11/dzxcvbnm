package Multithreading;

public class Triangle extends Shape {



    
    public Triangle(int sideA, int sideB, int sideC)
    {
        super(sideA,sideB,sideC);
    }



   @Override
    public double areaOfShape()
    {
        System.out.println("Area: ");
        return this.getSide1()*this.getSide2()*0.5;
    }
    
    @Override
    public double perimeterOfShape()
    {
        System.out.println("perimeter: ");
        return this.getSide1()+this.getSide2()+this.getSide3();
    }
}
