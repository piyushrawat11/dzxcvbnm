package Multithreading;

public class main_class extends Thread {
	
    public static void main(String[] args) throws InterruptedException{
        Asi_sycho a = new Asi_sycho();
        Thread t1 = new Thread(new Runnable() {
            @Override
            public  void  run() {
                try {
                    a.Producer();
                }
                catch(InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public  void  run() {
                try {
                    a.consumer();
                }
                catch(InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t1.start();
        t2.start();
        t1.join();
        t2.join();
    }