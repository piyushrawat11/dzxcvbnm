// GROUP C
//2ND PART

package Wrapper;

public class wrapper_class {

	public static void main(String[] args) {
	
		Integer P = 54;
		
		//int--.double
		double Q =  P.doubleValue();
		System.out.println("value of " +  P + " in double: " + Q);
		
			//int-->byte
		byte R =  P.byteValue();
		System.out.println("value of " +  P + " in byte: " + R);
		
		//int-->float
		float S =  P.floatValue();
		System.out.println("value of " +  P + " in float: " + S);
		
		//Int-->long
		long T =  P.longValue();
		System.out.println("value of " +  P + " in long: " + T);

		// int --> string
		String str =  P.toString();
		System.out.println("value of " +  P + " in String format: " + str);

		// string-->int
		String str1 = "10";
		int i = Integer.parseInt(str1);
		System.out.println("value of " + str1 + " in integer: " + i);

		//char -> string
		char ch = 'A';
        String str2 = String .valueOf(ch);
        System.out.println("value of " + ch + " in String: " + str2);
        
        
        //string -> 1st char from string
        String str3 = "Piyush";
        char c = str3.charAt(0);
        System.out.println("First value in " + str3 + " is: " + c);
		//dfghjk
        
        String str4="piyush ";
    	StringBuilder name= new StringBuilder(str4);
    	name.append("rawat");
    	System.out.println(name);
    	
    	name.insert(7,"singh ");
    	System.out.println(name);
    	
    	System.out.println(name.substring(7,18));
    	
    	name.replace(0,7,"Ayush ");
    	System.out.println(name);
    	
    	name.delete(0,11);
    	
    	System.out.println(name);
    	
    	System.out.println(name.charAt(6));
		
	}

}
